import { useEffect, useRef } from "react";
import { usePlayerStore } from "../store/usePlayerStore";

export function useAudio() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const setProgress = usePlayerStore((state) => state.setProgress);
  const nextTrack = usePlayerStore((state) => state.nextTrack);
  const togglePlayPause = usePlayerStore((state) => state.togglePlayPause);
  const currentTrack = usePlayerStore((state) => state.currentTrack);
  const isPlaying = usePlayerStore((state) => state.isPlaying);
  const volume = usePlayerStore((state) => state.volume);

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audio = audioRef.current;

    const handleTimeUpdate = () => {
      setProgress(audio.currentTime);
    };

    const handleEnded = () => {
      nextTrack();
    };

    const handleError = () => {
      console.error("Audio playback error");
      if (isPlaying) {
        togglePlayPause(); // Stop playing on error
      }
    };

    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("ended", handleEnded);
    audio.addEventListener("error", handleError);

    return () => {
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("ended", handleEnded);
      audio.removeEventListener("error", handleError);
    };
  }, [nextTrack, setProgress, togglePlayPause, isPlaying]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !currentTrack) return;

    if (audio.src !== currentTrack.audio) {
      audio.src = currentTrack.audio;
      audio.load();
    }

    if (isPlaying) {
      audio.play().catch((err) => {
        console.error("Failed to play audio:", err);
        if (isPlaying) togglePlayPause();
      });
    } else {
      audio.pause();
    }
  }, [currentTrack, isPlaying, togglePlayPause]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const seek = (time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setProgress(time);
    }
  };

  return { seek };
}

