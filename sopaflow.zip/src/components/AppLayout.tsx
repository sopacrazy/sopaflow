import { ReactNode } from "react";
import { Header } from "./Header";
import { PlayerBar } from "./PlayerBar";

interface AppLayoutProps {
  children: ReactNode;
  currentTab?: "home" | "favorites";
  onTabChange?: (tab: "home" | "favorites") => void;
}

export function AppLayout({ children, currentTab, onTabChange }: AppLayoutProps) {
  return (
    <div className="flex flex-col min-h-screen bg-zinc-950 text-zinc-50 font-sans selection:bg-indigo-500/30">
      <Header currentTab={currentTab} onTabChange={onTabChange} />
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-32">
        {children}
      </main>
      <PlayerBar />
    </div>
  );
}

