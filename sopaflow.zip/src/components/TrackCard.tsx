import { Heart, Play, Pause } from "lucide-react";
import { Track } from "../types";
import { usePlayerStore } from "../store/usePlayerStore";
import { useFavoritesStore } from "../store/useFavoritesStore";
import { cn } from "../utils/cn";

interface TrackCardProps {
  track: Track;
  queue?: Track[];
}

export function TrackCard({ track, queue }: TrackCardProps) {
  const { currentTrack, isPlaying, playTrack, togglePlayPause } = usePlayerStore();
  const { isFavorite, toggleFavorite } = useFavoritesStore();

  const isCurrentTrack = currentTrack?.id === track.id;
  const isFavoriteTrack = isFavorite(track.id);

  const handlePlayClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isCurrentTrack) {
      togglePlayPause();
    } else {
      playTrack(track, queue);
    }
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(track);
  };

  return (
    <div
      className="group relative flex flex-col gap-3 p-3 rounded-2xl bg-zinc-900/40 hover:bg-zinc-800/60 border border-transparent hover:border-zinc-700/50 transition-all duration-300 cursor-pointer"
      onClick={handlePlayClick}
    >
      <div className="relative aspect-square w-full overflow-hidden rounded-xl shadow-md">
        <img
          src={track.image || "https://picsum.photos/seed/music/400/400"}
          alt={track.name}
          className={cn(
            "object-cover w-full h-full transition-transform duration-500 group-hover:scale-105",
            isCurrentTrack && "scale-105"
          )}
          referrerPolicy="no-referrer"
          loading="lazy"
        />
        
        {/* Overlay */}
        <div
          className={cn(
            "absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity duration-300",
            isCurrentTrack ? "opacity-100" : "opacity-0 group-hover:opacity-100"
          )}
        >
          <button
            className="w-12 h-12 flex items-center justify-center rounded-full bg-indigo-500 text-white shadow-lg transform transition-transform hover:scale-110 active:scale-95"
            onClick={handlePlayClick}
          >
            {isCurrentTrack && isPlaying ? (
              <Pause className="w-5 h-5 fill-current" />
            ) : (
              <Play className="w-5 h-5 fill-current ml-1" />
            )}
          </button>
        </div>

        {/* Favorite Button */}
        <button
          onClick={handleFavoriteClick}
          className={cn(
            "absolute top-2 right-2 p-2 rounded-full backdrop-blur-md transition-all duration-200",
            isFavoriteTrack
              ? "bg-zinc-900/80 text-rose-500 opacity-100"
              : "bg-zinc-900/40 text-zinc-300 opacity-0 group-hover:opacity-100 hover:bg-zinc-900/80 hover:text-white"
          )}
        >
          <Heart className={cn("w-4 h-4", isFavoriteTrack && "fill-current")} />
        </button>
      </div>

      <div className="flex flex-col px-1">
        <h3
          className={cn(
            "font-medium text-sm truncate transition-colors",
            isCurrentTrack ? "text-indigo-400" : "text-zinc-100 group-hover:text-white"
          )}
          title={track.name}
        >
          {track.name}
        </h3>
        <p
          className="text-xs text-zinc-500 truncate mt-0.5"
          title={track.artist_name}
        >
          {track.artist_name}
        </p>
      </div>
    </div>
  );
}
