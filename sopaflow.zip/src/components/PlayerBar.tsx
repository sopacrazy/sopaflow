import { Play, Pause, SkipBack, SkipForward, Repeat, Shuffle, Volume2, VolumeX } from "lucide-react";
import { usePlayerStore } from "../store/usePlayerStore";
import { useAudio } from "../hooks/useAudio";
import { ProgressBar } from "./ProgressBar";
import { VolumeControl } from "./VolumeControl";
import { cn } from "../utils/cn";

export function PlayerBar() {
  const {
    currentTrack,
    isPlaying,
    togglePlayPause,
    nextTrack,
    prevTrack,
    isRepeating,
    toggleRepeat,
    isShuffling,
    toggleShuffle,
    volume,
    setVolume,
  } = usePlayerStore();

  const { seek } = useAudio();

  if (!currentTrack) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-zinc-950/95 backdrop-blur-xl border-t border-zinc-800/80 px-2 py-2 sm:px-6 sm:py-3">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 sm:gap-4">
        
        {/* Track Info */}
        <div className="flex items-center gap-3 w-full sm:w-1/3 min-w-0 justify-between sm:justify-start">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative w-10 h-10 sm:w-12 sm:h-12 rounded-md overflow-hidden flex-shrink-0 bg-zinc-800">
              <img
                src={currentTrack.image || "https://picsum.photos/seed/music/100/100"}
                alt={currentTrack.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-medium text-zinc-100 truncate">
                {currentTrack.name}
              </span>
              <span className="text-xs text-zinc-400 truncate">
                {currentTrack.artist_name}
              </span>
            </div>
          </div>
          
          {/* Mobile Play/Pause (visible only on very small screens if we want, but let's keep controls central) */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={togglePlayPause}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-zinc-100 text-zinc-950 hover:scale-105 active:scale-95 transition-all"
            >
              {isPlaying ? (
                <Pause className="w-5 h-5 fill-current" />
              ) : (
                <Play className="w-5 h-5 fill-current ml-1" />
              )}
            </button>
          </div>
        </div>

        {/* Controls & Progress */}
        <div className="flex flex-col items-center w-full sm:w-1/3 max-w-md gap-1 sm:gap-2">
          <div className="hidden sm:flex items-center gap-4 sm:gap-6">
            <button
              onClick={toggleShuffle}
              className={cn(
                "p-2 rounded-full transition-colors",
                isShuffling ? "text-indigo-400" : "text-zinc-400 hover:text-zinc-200"
              )}
            >
              <Shuffle className="w-4 h-4" />
            </button>
            
            <button
              onClick={prevTrack}
              className="text-zinc-400 hover:text-zinc-200 transition-colors"
            >
              <SkipBack className="w-5 h-5 fill-current" />
            </button>
            
            <button
              onClick={togglePlayPause}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-zinc-100 text-zinc-950 hover:scale-105 active:scale-95 transition-all"
            >
              {isPlaying ? (
                <Pause className="w-5 h-5 fill-current" />
              ) : (
                <Play className="w-5 h-5 fill-current ml-1" />
              )}
            </button>
            
            <button
              onClick={nextTrack}
              className="text-zinc-400 hover:text-zinc-200 transition-colors"
            >
              <SkipForward className="w-5 h-5 fill-current" />
            </button>
            
            <button
              onClick={toggleRepeat}
              className={cn(
                "p-2 rounded-full transition-colors",
                isRepeating ? "text-indigo-400" : "text-zinc-400 hover:text-zinc-200"
              )}
            >
              <Repeat className="w-4 h-4" />
            </button>
          </div>
          
          <div className="w-full flex items-center gap-2 sm:gap-3 px-2 sm:px-0">
            <ProgressBar duration={currentTrack.duration} onSeek={seek} />
          </div>
        </div>

        {/* Volume Control */}
        <div className="hidden sm:flex items-center justify-end w-1/3 gap-3">
          <button
            onClick={() => setVolume(volume === 0 ? 0.8 : 0)}
            className="text-zinc-400 hover:text-zinc-200 transition-colors"
          >
            {volume === 0 ? (
              <VolumeX className="w-5 h-5" />
            ) : (
              <Volume2 className="w-5 h-5" />
            )}
          </button>
          <VolumeControl />
        </div>
      </div>
    </div>
  );
}

