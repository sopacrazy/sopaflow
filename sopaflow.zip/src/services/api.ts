import { Track } from "../types";

const API_BASE = "https://api.jamendo.com/v3.0";
// Fallback client ID for testing if not provided in env
const CLIENT_ID = import.meta.env.VITE_JAMENDO_CLIENT_ID || "b6747d04";

export const jamendoApi = {
  async searchTracks(query: string, limit = 20): Promise<Track[]> {
    try {
      const params = new URLSearchParams({
        client_id: CLIENT_ID,
        format: "json",
        limit: limit.toString(),
        search: query,
        include: "musicinfo",
        audioformat: "mp32",
      });

      const response = await fetch(`${API_BASE}/tracks/?${params}`);
      if (!response.ok) throw new Error("Failed to fetch tracks");
      
      const data = await response.json();
      return data.results || [];
    } catch (error) {
      console.error("Error searching tracks:", error);
      throw error;
    }
  },

  async getTracksByTags(tags: string[], limit = 20): Promise<Track[]> {
    try {
      const params = new URLSearchParams({
        client_id: CLIENT_ID,
        format: "json",
        limit: limit.toString(),
        tags: tags.join(","),
        include: "musicinfo",
        audioformat: "mp32",
      });

      const response = await fetch(`${API_BASE}/tracks/?${params}`);
      if (!response.ok) throw new Error("Failed to fetch tracks");
      
      const data = await response.json();
      return data.results || [];
    } catch (error) {
      console.error("Error fetching tracks by tags:", error);
      throw error;
    }
  },
};
