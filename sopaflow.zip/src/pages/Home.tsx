import { useEffect, useState, useCallback } from "react";
import { SearchBar } from "../components/SearchBar";
import { CategoryChips } from "../components/CategoryChips";
import { TrackGrid } from "../components/TrackGrid";
import { TrackCard } from "../components/TrackCard";
import { EmptyState } from "../components/EmptyState";
import { LoadingState } from "../components/LoadingState";
import { jamendoApi } from "../services/api";
import { Track } from "../types";
import { toast } from "sonner";

const CATEGORIES = [
  "Foco",
  "Piano",
  "Ambiente",
  "Lo-fi",
  "Relaxamento",
  "Instrumental",
  "Meditação",
];

export function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchTracks = useCallback(async (query: string, category: string | null) => {
    setIsLoading(true);
    try {
      let results: Track[] = [];
      if (query) {
        results = await jamendoApi.searchTracks(query);
      } else if (category) {
        results = await jamendoApi.getTracksByTags([category.toLowerCase()]);
      } else {
        // Default tracks for "Para estudar agora"
        results = await jamendoApi.getTracksByTags(["study", "focus", "lofi"], 30);
      }
      setTracks(results);
    } catch (error) {
      toast.error("Falha ao carregar as músicas. Tente novamente mais tarde.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTracks(searchQuery, selectedCategory);
  }, [searchQuery, selectedCategory, fetchTracks]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query) {
      setSelectedCategory(null);
    }
  };

  const handleCategorySelect = (category: string | null) => {
    setSelectedCategory(category);
    if (category) {
      setSearchQuery("");
    }
  };

  const getSectionTitle = () => {
    if (searchQuery) return `Resultados da busca por "${searchQuery}"`;
    if (selectedCategory) return `Músicas de ${selectedCategory}`;
    return "Para estudar agora";
  };

  return (
    <div className="flex flex-col gap-8 animate-in fade-in duration-500">
      <div className="flex flex-col items-center text-center space-y-4 py-8">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white">
          Encontre o seu <span className="text-indigo-400">foco</span>
        </h1>
        <p className="text-zinc-400 max-w-2xl text-lg">
          Mergulhe em músicas cuidadosamente selecionadas para melhorar sua concentração e produtividade.
        </p>
      </div>

      <SearchBar onSearch={handleSearch} />
      
      {!searchQuery && (
        <CategoryChips
          categories={CATEGORIES}
          selectedCategory={selectedCategory}
          onSelect={handleCategorySelect}
        />
      )}

      <div className="mt-4">
        {isLoading ? (
          <LoadingState />
        ) : tracks.length > 0 ? (
          <TrackGrid title={getSectionTitle()}>
            {tracks.map((track) => (
              <TrackCard key={track.id} track={track} queue={tracks} />
            ))}
          </TrackGrid>
        ) : (
          <EmptyState />
        )}
      </div>
    </div>
  );
}
