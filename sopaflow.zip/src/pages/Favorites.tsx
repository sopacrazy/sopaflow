import { TrackGrid } from "../components/TrackGrid";
import { TrackCard } from "../components/TrackCard";
import { EmptyState } from "../components/EmptyState";
import { useFavoritesStore } from "../store/useFavoritesStore";

export function Favorites() {
  const { favorites } = useFavoritesStore();

  return (
    <div className="flex flex-col gap-8 animate-in fade-in duration-500">
      <div className="py-8">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-white">
          Seus <span className="text-rose-400">Favoritos</span>
        </h1>
        <p className="text-zinc-400 mt-2">
          Músicas que você salvou para ouvir depois.
        </p>
      </div>

      {favorites.length > 0 ? (
        <TrackGrid>
          {favorites.map((track) => (
            <TrackCard key={track.id} track={track} queue={favorites} />
          ))}
        </TrackGrid>
      ) : (
        <EmptyState
          title="Nenhum favorito ainda"
          description="Comece a explorar e curta as músicas que você ama para criar sua playlist pessoal de foco."
        />
      )}
    </div>
  );
}
